<#
  Ghost Watchers save editor
  - money, player level, all skins/bracelets/drones, all lobby decorations,
    all capsule upgrades, all ghosts on Diamond statue (200 caught)
  - backs up the old save first (SavesDir_backup_<timestamp> in the game folder)
  - closes the game if it's running, edits the save, then starts the game again

  Usage:  double-click "Run Save Editor.bat"
     or:  powershell -ExecutionPolicy Bypass -File GhostWatchersSaveEditor.ps1 [-Money 100000000] [-Level 112] [-GamePath "D:\...\Ghost Watchers"]
#>
param(
    [int]$Money = 100000000,
    [ValidateRange(1, 1000)][int]$Level = 112,
    [int]$GhostsCaught = 200,
    [string]$GamePath,
    [switch]$NoRestart
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web.Extensions

$AppId = '1850740'
$Pass  = 'thisIsSparta!'

function Find-GamePath {
    $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction SilentlyContinue).SteamPath
    if (-not $steam) { throw 'Steam not found. Start with -GamePath "<Ghost Watchers folder>".' }
    $libs = @($steam.Replace('/', '\'))
    $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
        $libs += [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"') | ForEach-Object { $_.Groups[1].Value.Replace('\\', '\') }
    }
    foreach ($lib in ($libs | Select-Object -Unique)) {
        $acf = Join-Path $lib "steamapps\appmanifest_$AppId.acf"
        if (Test-Path $acf) {
            $dir = [regex]::Match((Get-Content $acf -Raw), '"installdir"\s+"([^"]+)"').Groups[1].Value
            return Join-Path $lib "steamapps\common\$dir"
        }
    }
    throw 'Ghost Watchers is not installed in any Steam library. Start with -GamePath "<Ghost Watchers folder>".'
}

function StableHash([string]$t) {
    [int64]$n = 23
    foreach ($c in $t.ToCharArray()) { $n = ($n * 31 + [int]$c) % 4294967296 }
    if ($n -ge 2147483648) { $n -= 4294967296 }
    [int]$n
}

function Decrypt-Save([string]$text) {
    $all = [Convert]::FromBase64String($text.Trim())
    $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes($Pass, [byte[]]$all[0..15], 1000)
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'
    $ct = [byte[]]$all[32..($all.Length - 1)]
    $pt = $aes.CreateDecryptor($kdf.GetBytes(16), [byte[]]$all[16..31]).TransformFinalBlock($ct, 0, $ct.Length)
    [Text.Encoding]::UTF8.GetString($pt)
}

function Encrypt-Save([string]$plain) {
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $salt = New-Object byte[] 16; $iv = New-Object byte[] 16
    $rng.GetBytes($salt); $rng.GetBytes($iv)
    $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes($Pass, $salt, 1000)
    $aes = [Security.Cryptography.Aes]::Create(); $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'
    $pt = [Text.Encoding]::UTF8.GetBytes($plain)
    $ct = $aes.CreateEncryptor($kdf.GetBytes(16), $iv).TransformFinalBlock($pt, 0, $pt.Length)
    [Convert]::ToBase64String([byte[]]($salt + $iv + $ct))
}

# --- locate game + close it --------------------------------------------------
if (-not $GamePath) { $GamePath = Find-GamePath }
$savesDir = Join-Path $GamePath 'SavesDir'
$saveFile = Join-Path $savesDir 'data.json'
Write-Host "Game folder: $GamePath"

$proc = Get-Process 'Ghost Watchers' -ErrorAction SilentlyContinue
if ($proc -and -not $NoRestart) {
    Write-Host 'Closing Ghost Watchers...'
    $proc | ForEach-Object { $_.CloseMainWindow() | Out-Null }
    Start-Sleep -Seconds 10
    Get-Process 'Ghost Watchers' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Seconds 2
}

# --- backup + load -------------------------------------------------------------
$json = New-Object Web.Script.Serialization.JavaScriptSerializer
$json.MaxJsonLength = [int]::MaxValue
$data = New-Object 'System.Collections.Generic.Dictionary[string,object]'

if (Test-Path $saveFile) {
    $backup = Join-Path $GamePath ('SavesDir_backup_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Copy-Item $savesDir $backup -Recurse
    Write-Host "Backup:      $backup"
    $data = $json.Deserialize((Decrypt-Save (Get-Content $saveFile -Raw)), [System.Collections.Generic.Dictionary[string, object]])
} else {
    New-Item -ItemType Directory -Force $savesDir | Out-Null
    Write-Host 'No existing save found, creating a new one.'
}

# --- edits -------------------------------------------------------------------------
# Level -> XP: game uses level = floor(0.1 * sqrt(xp)); pick the middle of the level
$exp = [int][math]::Pow(($Level + 0.5) * 10, 2)
$data['dollars'] = "$Money"
$data['exp']     = "$exp"

# Shop items (IDs = stable hash of name): skins, bracelets, drones
$shopNames = 'joeafro','joebomber1','joebomber2','joebomber3','joebomber4','joedefault','joehunter','joenewSkin',
             'nancyasian','nancydefault','nancyhunter','nancyleather_pants','nancytop1','nancytop2','nancytop3','nancytop4',
             'None','Ordinary','Improved','AfterDeath','SaveTools','Mercenary','Light','Detector','Cargo'
$shop = New-Object 'System.Collections.Generic.List[int]'
if ($data.ContainsKey('shop_items') -and $data['shop_items'] -and $data['shop_items'] -ne 'null') {
    foreach ($i in $json.Deserialize($data['shop_items'], [int[]])) { if (-not $shop.Contains($i)) { $shop.Add($i) } }
}
foreach ($n in $shopNames) { $h = StableHash $n; if (-not $shop.Contains($h)) { $shop.Add($h) } }
$data['shop_items'] = '[' + ($shop -join ',') + ']'

# Lobby decorations: <zone>_<object>_<improvement>
$lobby = '3_0_1','3_0_2','3_1_1','3_1_2','1_0_1','1_1_1','1_1_2','1_2_1','8_0_1','8_0_2','8_0_3','8_0_4','8_0_5','8_0_6',
         '8_1_1','8_1_2','8_2_1','8_2_2','8_3_1','8_4_1','7_0_1','7_0_2','7_1_1','7_1_2','7_1_3','7_2_1','7_2_2','7_3_1',
         '7_3_2','7_3_3','7_4_1','7_4_2','7_4_3','7_5_1','7_6_1','7_7_1','7_8_1','9_0_1','9_1_1','9_1_2','9_2_1','9_2_2',
         '9_3_1','9_3_2','9_3_3','9_4_1','9_4_2','9_4_3','9_4_4','9_5_1','9_6_1','9_7_1','9_7_2','0_0_1','0_0_2','0_1_1',
         '0_1_2','0_2_1','0_2_2','0_3_1','0_3_2','0_4_1','0_4_2','0_5_1','0_5_2','0_6_1','0_7_1','0_7_2','0_8_1','0_8_2',
         '4_0_1','4_0_2','4_0_3','4_1_1','4_1_2','4_1_3','5_0_1','5_0_2','5_1_1','5_1_2','5_2_1','5_2_2','6_0_1','6_0_2',
         '6_0_3','6_1_1','6_1_2','2_0_1'
foreach ($l in $lobby) { $data["${l}_lobby_environment_obj_purchased"] = 'true' }

foreach ($d in 'Light','Detector','Cargo') { $data["${d}_drone"] = 'true' }

# Ghosts: capsule upgrade + caught count (200 = Diamond statue, max tier)
$ghosts = 'Poltergeist','GallowsGhost','Baby','Twins','Drowned','Doppelganger','Darkness','Vampire','Demon','SupremeDemon',
          'Jiangshi','KarlssonOnTheRoof','Puppet','DreamDevourer','Nun','Babadook','Krampus','KuchisakeOnna','Ghoul',
          'Vendigo','IronMaiden','Plague','Clown','BloodyCountess','Mummy','ElectroDoctor','YellowKing','Witch'
foreach ($g in $ghosts) {
    $data["${g}_capsule"] = 'true'
    $data["${g}_caught"]  = "$GhostsCaught"
}

# --- save --------------------------------------------------------------------------
$encrypted = Encrypt-Save ($json.Serialize($data))
[IO.File]::WriteAllText($saveFile, $encrypted, (New-Object Text.UTF8Encoding $false))
Remove-Item -LiteralPath "$saveFile.bak" -Force -ErrorAction SilentlyContinue

# verify
$check = $json.Deserialize((Decrypt-Save (Get-Content $saveFile -Raw)), [System.Collections.Generic.Dictionary[string, object]])
Write-Host ''
Write-Host "Done! Money: $($check['dollars'])  Level: $Level  Ghosts: $GhostsCaught caught each  Items: $($shop.Count) shop + $($lobby.Count) lobby" -ForegroundColor Green
Write-Host 'If Steam asks about a cloud save conflict, choose LOCAL.' -ForegroundColor Yellow

if (-not $NoRestart) {
    Write-Host 'Starting Ghost Watchers...'
    Start-Process "steam://rungameid/$AppId"
}

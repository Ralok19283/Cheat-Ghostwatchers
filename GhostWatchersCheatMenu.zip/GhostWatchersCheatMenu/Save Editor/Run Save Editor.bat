@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0GhostWatchersSaveEditor.ps1" %*
timeout /t 5
